package server

import (
	"go-canonical/internal/common"
	"go-canonical/internal/handlers"
	"log"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
)

var envVars common.EnvVars

func StartServer(argEnvVars common.EnvVars) {
	envVars = argEnvVars
	e := echo.New()
	e.Debug = true

	// Middleware
	e.Pre(middleware.RemoveTrailingSlash())
	e.Use(middleware.Logger())
	e.Use(middleware.Recover())

	NewTemplateRenderer(e, "web/public/*.html", "web/templates/*.html")

	handlers.SetupRoutes(e)

	if envVars.HttpPort == "" {
		envVars.HttpPort = "8080"
	}

	log.Print("Starting server on port " + envVars.HttpPort)
	e.Logger.Fatal(e.Start(":" + envVars.HttpPort))
}
