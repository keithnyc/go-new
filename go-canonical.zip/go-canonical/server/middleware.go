package server

import (
	"github.com/labstack/echo/v4"
)

func TokenMiddleware(token string) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			c.Set("X-Auth-Token", token)
			return next(c)
		}
	}
}
