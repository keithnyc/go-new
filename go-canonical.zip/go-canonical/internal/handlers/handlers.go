package handlers

import (
	"net/http"

	"github.com/labstack/echo/v4"
)

type IndexTemplateData struct {
	Title     string
	ActiveNav string
}

func SetupRoutes(e *echo.Echo) {
	e.Static("/public", "web/static")
	e.GET("/api/v1/health", healthCheck)
	e.GET("/", index)
}

func index(c echo.Context) error {
	templateData := IndexTemplateData{
		ActiveNav: "index",
	}
	return c.Render(http.StatusOK, "index", templateData)
}
func healthCheck(c echo.Context) error {
	// ...
	return c.String(http.StatusOK, "OK")
}
