package data

import "gorm.io/gorm"

func SetupDatabase(dsn string) *gorm.DB {
	// ...
	return nil
}
