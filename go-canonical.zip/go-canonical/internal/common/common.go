package common

type EnvVars struct {
	// ...
	HttpPort string
}
