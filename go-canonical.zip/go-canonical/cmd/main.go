package main

import (
	"go-canonical/internal/common"
	"go-canonical/server"
)

func main() {
	// ...
	envVars := checkEnvVars()
	server.StartServer(envVars)
}

func checkEnvVars() common.EnvVars {
	// ...
	envvars := common.EnvVars{}
	return envvars
}
